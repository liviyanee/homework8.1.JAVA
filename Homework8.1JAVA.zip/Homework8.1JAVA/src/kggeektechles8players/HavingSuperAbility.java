package kggeektechles8players;

public interface HavingSuperAbility {
    void applySuperAbility(Boss boss, Hero[] heroes);
}
