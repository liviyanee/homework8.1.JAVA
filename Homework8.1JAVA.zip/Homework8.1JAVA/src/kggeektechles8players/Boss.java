package kggeektechles8players;

public class Boss extends GameEntity {
    public Boss(int health, int damage) {
        super(health, damage);
    }
}
